# PowerAi PdfViewer PCF

A PCF control for model-driven apps that renders a PDF from a Dataverse file column using PDF.js.

## Quick Start (CI)
1) Push repo to GitHub.
2) Run GitHub Action **Build Managed Solution**.
3) Download artifact `PowerAi.PdfViewer_Managed.zip` and import to your environment.
